import React from 'react';
import PropTypes from 'prop-types';
import noop from 'noop';
import './button.css';

const Button = ({onClick, text}) => {
    return <div className='button-wrapper' onClick={onClick}>
        {text}
    </div>
}

Button.defaultProps = {
	text: 'click',
    onClick: noop
};

Button.propTypes = {
    text: PropTypes.string,
    onClick: PropTypes.func,
};


export {
    Button
}
