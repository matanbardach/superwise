import React, { useCallback, useState } from "react";
import { getDataPoint } from './api/dataPoint';
import { LineChart } from './chart';
import { Button } from "./button";
import './mainPage.css';

const MainPage = () => {
    const [from, setFrom] = useState('');
    const [to, setTo] = useState('');
    const [chartData, setChartData] = useState([]);
    const [labels, setLabels] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    const fetchDataPoint = useCallback(async () => {
        const myData = await getDataPoint(from, to);
    }, [from, to]);
    // const 
    return (<div className="main-page">
        <Button text={'fetch data'} onClick={fetchDataPoint}/>
        <LineChart data={chartData} labels={labels}/>
    </div>)
}

export default MainPage;

