import Loading from 'react-simple-loading';
import './loader.css';
const Loader = () => <div className="loader">
    <Loading/>
</div>;

export default Loader;