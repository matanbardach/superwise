// import fetch from 'node-fetch';
const baseUrl = 'http://localhost:3001/recall';

const getDataPoint = async (from = '', to = '') => {
	const url = from || to ? baseUrl : `${baseUrl}?`;
	try {
		const { data } = await fetch(`${url}from_ts=${from}&to_ts=${to}`);
		return { status: 'ok', data };
	} catch {
		return { status: 'err' };
	}
};

export { 
    getDataPoint
};
