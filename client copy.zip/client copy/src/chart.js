import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { Line } from 'react-chartjs-2';
import Loading from 'react-simple-loading';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

export const options = {
	responsive: true,
	plugins: {
		title: {
			display: true,
			text: 'Matan home exercise',
		},
	},
};

// const labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
// const baseData = {
// 	labels: [],
// 	datasets: [
// 		{
// 			label: 'Data Point',
// 			data: [],
// 			borderColor: 'rgb(255, 99, 132)',
// 			backgroundColor: 'rgba(255, 99, 132, 0.5)',
// 		},
// 	],
// };

const datasets = {
    label: 'Data Point',
    data: [],
    borderColor: 'rgb(255, 99, 132)',
    backgroundColor: 'rgba(255, 99, 132, 0.5)',
}
const LineChart = ({data, labels}) => {
    const dataObject = useMemo(() => ({
        labels,
        datasets: [
            {...datasets, data: data}
        ]
    }), [data, labels]);
    return (<div className='chart-wrapper'>
        <Line options={options} data={dataObject} />
    </div>);
};

LineChart.defaultProps = {
	data: [],
    labels: []
};

LineChart.propTypes = {
    data: PropTypes.array,
    onClick: PropTypes.array,
};

export { LineChart };
