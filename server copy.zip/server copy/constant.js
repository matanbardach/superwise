const DATE_FORMAT = 'YYYY-MM-DD';

module.exports = {
    DATE_FORMAT
}