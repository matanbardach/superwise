const dayjs = require('dayjs');
const customParseFormat = require('dayjs/plugin/customParseFormat');
const { DATE_FORMAT } = require('./constant');
dayjs.extend(customParseFormat)

const validateQueryDate = (req, res, next) => {
    const { query: { from_ts, to_ts } } = req;
    let isValid = true;
    const isFromValid = dayjs(from_ts, DATE_FORMAT, true).isValid();
    const isToValid = dayjs(to_ts, DATE_FORMAT, true).isValid();
    if (from_ts && to_ts && from_ts !== to_ts) {
        if(!dayjs(from_ts).isBefore(dayjs(to_ts))) {
            isValid = false;
        }
    }
    if((from_ts && !isFromValid) || (to_ts && !isToValid)) {
        isValid = false
    }
    if(isValid) {
        next();        
    } else {
        return res.status(400).send('Invalid date range');
    }
}

module.exports = {
    validateQueryDate
}