const express = require('express');
const { validateQueryDate } = require('./middleware')
const { queryDataPoint, getAllData } = require('./db_query');
const { initDbToCache } = require('./db_query');
const app = express();
const port = 3001;

app.get('/recall', validateQueryDate, async (req, res) => {
  const { query: { from_ts, to_ts } } = req;
  const myData = await queryDataPoint(from_ts, to_ts);
  const allData = getAllData();
console.log('THE ALL DATA: ' , allData);
  res.json(myData);
})

app.listen(port, async () => {
  await initDbToCache();
  console.log(`Example app listening on port ${port}`)
})