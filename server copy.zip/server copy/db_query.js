const dayjs = require('dayjs');
const fs = require("fs");
const csv = require("csv-parser");
const { DATE_FORMAT } = require('./constant');

let myData = [];
let dataLength = 0;
const mayDateToIndex = {

}
const initDbToCache = () => {
    return new Promise((res) => {
        fs.createReadStream("./serverData/recall_data.csv")
        .pipe(csv())
        .on("data", data => { 
            myData.push({...data, date: dayjs(data.date).format(DATE_FORMAT) });
         })
         .on('end', () => {
            myData.sort((a, b) => (dayjs(b.date).isAfter(dayjs(a.date))));
            dataLength = myData.length;
            for(dataPointIndex in myData) {
                mayDateToIndex[myData[dataPointIndex].date] = dataPointIndex
            }
            res()
         });
    })
}
const queryDataPoint = async (fromDate, toDate) => {
    return new Promise((resolve) => {
        setTimeout(() => {
            let fromIndex = mayDateToIndex[fromDate] || 0;
            let toIndex = mayDateToIndex[toDate] && mayDateToIndex[toDate] < dataLength ? mayDateToIndex[toDate] : dataLength;
            resolve(myData.slice(fromIndex, toIndex + 1));
          }, 3000);
    })
}

const getAllData = () => {
    return myData;
}
module.exports = {
    queryDataPoint,
    initDbToCache,
    getAllData
}